package com.waza.skeletonrunningpast

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.ImageView
import java.io.IOException
import kotlin.random.Random

class SkeletonService : Service() {
    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var activeView: ImageView? = null
    private var player: MediaPlayer? = null
    private var running = false
    private val channelId = "skeleton_running_past"

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
        val stopIntent = PendingIntent.getService(
            this, 10, Intent(this, SkeletonService::class.java).setAction("STOP"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channelId)
                .setContentTitle("Skeleton Running Past está activo")
                .setContentText("Toca DETENER para apagarlo.")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .addAction(Notification.Action.Builder(null, "DETENER", stopIntent).build())
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Skeleton Running Past está activo")
                .setContentText("El esqueleto puede aparecer.")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .build()
        }
        startForeground(77, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!running) {
            running = true
            scheduleCheck()
        }
        return START_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(
                channelId, "Skeleton Running Past", NotificationManager.IMPORTANCE_LOW
            ))
        }
    }

    private fun scheduleCheck() {
        handler.postDelayed({
            if (running) {
                // 1 in 12 chance each second; avoids constant interruptions.
                if (Random.nextInt(12) == 0 && activeView == null) showSkeleton()
                scheduleCheck()
            }
        }, 1000)
    }

    private fun showSkeleton() {
        val metrics = resources.displayMetrics
        val screenW = metrics.widthPixels
        val screenH = metrics.heightPixels
        val images = mutableListOf<android.graphics.Bitmap>()
        for (i in 1..23) {
            try {
                assets.open("frames/frame_%02d.png".format(i)).use {
                    images.add(BitmapFactory.decodeStream(it))
                }
            } catch (_: Exception) {}
        }
        if (images.isEmpty()) return
        val targetHeight = (screenH * 0.30f).toInt().coerceAtLeast(100)
        val ratio = images[0].width.toFloat() / images[0].height.toFloat()
        val targetWidth = (targetHeight * ratio).toInt()
        val view = ImageView(this)
        activeView = view
        val params = WindowManager.LayoutParams(
            targetWidth, targetHeight,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = screenW
        params.y = Random.nextInt(0, (screenH - targetHeight).coerceAtLeast(1))
        try {
            wm.addView(view, params)
        } catch (_: Exception) {
            activeView = null
            images.forEach { it.recycle() }
            return
        }
        playSound()
        val totalDistance = screenW + targetWidth
        val frameDelay = 26L
        val steps = images.size
        var index = 0
        val startY = params.y
        val animate = object : Runnable {
            override fun run() {
                if (!running || activeView !== view) {
                    cleanup(view, images)
                    return
                }
                if (index >= steps) {
                    cleanup(view, images)
                    return
                }
                params.x = screenW - (totalDistance * index / (steps - 1))
                params.y = startY
                view.setImageBitmap(images[index])
                try { wm.updateViewLayout(view, params) } catch (_: Exception) {}
                index++
                handler.postDelayed(this, frameDelay)
            }
        }
        handler.post(animate)
    }

    private fun playSound() {
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(assets.openFd("skeleton_violin.wav").fileDescriptor,
                    assets.openFd("skeleton_violin.wav").startOffset,
                    assets.openFd("skeleton_violin.wav").length)
                setVolume(1.0f, 1.0f)
                setOnCompletionListener { it.release(); if (player === it) player = null }
                prepare()
                start()
            }
        } catch (_: Exception) {
            try {
                val afd = assets.openFd("skeleton_violin.wav")
                val mp = MediaPlayer()
                mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                mp.setVolume(1.0f, 1.0f)
                mp.setOnCompletionListener { it.release(); if (player === it) player = null }
                mp.prepare()
                mp.start()
                player = mp
            } catch (_: Exception) {}
        }
    }

    private fun cleanup(view: ImageView, images: List<android.graphics.Bitmap>) {
        try { wm.removeView(view) } catch (_: Exception) {}
        if (activeView === view) activeView = null
        images.forEach { if (!it.isRecycled) it.recycle() }
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        activeView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        activeView = null
        player?.release()
        player = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
