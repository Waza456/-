package com.waza.skeletonrunningpast

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestCodeOverlay = 773

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
        }
        layout.addView(TextView(this).apply {
            text = "👀 SKELETON RUNNING PAST 💀"
            textSize = 22f
            gravity = Gravity.CENTER
        })
        layout.addView(TextView(this).apply {
            text = "\nEl esqueleto cruzará la pantalla por encima de otras aplicaciones y sonará el violín.\n\nActiva el permiso de superposición para empezar."
            textSize = 16f
            gravity = Gravity.CENTER
        })
        layout.addView(Button(this).apply {
            text = "ACTIVAR ESQUELETO 💀"
            setOnClickListener { startOverlay() }
        })
        layout.addView(Button(this).apply {
            text = "DETENER"
            setOnClickListener {
                stopService(Intent(this@MainActivity, SkeletonService::class.java))
                Toast.makeText(this@MainActivity, "Skeleton detenido 👀", Toast.LENGTH_SHORT).show()
            }
        })
        setContentView(layout)
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName"))
            startActivityForResult(intent, requestCodeOverlay)
            Toast.makeText(this, "Permite «Mostrar sobre otras aplicaciones» y vuelve aquí.", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(this, SkeletonService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        Toast.makeText(this, "¡Esqueleto activado! 💀💨", Toast.LENGTH_SHORT).show()
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCodeOverlay && Settings.canDrawOverlays(this)) startOverlay()
    }
}
